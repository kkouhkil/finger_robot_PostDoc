var page_user_guide_build =
[
    [ "Compatibility", "page_user_guide_build.html#section_porting_code_older", null ],
    [ "Compiling and Linking on Windows", "page_user_guide_build_compiling_linking_windows.html", [
      [ "Compiling and Linking Your Code on Windows", "page_user_guide_build_compiling_linking_windows.html#section_user_guide_build_compiling_linking_windows", null ],
      [ "Deploying Your Application", "page_user_guide_build_compiling_linking_windows.html#section_user_guide_build_installation_deploy", null ],
      [ "Redistributable Files in CANlib SDK", "page_user_guide_build_compiling_linking_windows.html#section_user_guide_intro_redistributable", null ]
    ] ],
    [ "Compiling and Linking on Linux", "page_user_guide_build_compiling_linking_linux.html", [
      [ "Linking Your Code on Linux", "page_user_guide_build_compiling_linking_linux.html#section_user_guide_build_compiling_linking_linux", null ]
    ] ]
];