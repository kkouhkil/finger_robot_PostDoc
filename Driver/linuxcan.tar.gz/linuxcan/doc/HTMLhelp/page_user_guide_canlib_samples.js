var page_user_guide_canlib_samples =
[
    [ "Monitor CAN channel", "page_example_c_candump.html", null ],
    [ "List CAN channels", "page_example_c_channeldata.html", null ],
    [ "Receive and reply to CAN message", "page_example_c_echo.html", null ],
    [ "Multi threading in CANlib", "page_example_c_threads.html", null ],
    [ "Echo server", "page_example_c_canecho.html", null ],
    [ "Send database signal", "page_example_c_gensig.html", null ],
    [ "High frequency sampling with CANtegrity", "page_example_c_kvdiag_normal.html", null ],
    [ "Bitrate calculation with CANtegrity", "page_example_c_kvdiag_autobaud.html", null ]
];